<div align="center">
  <h3>✨NITRO-GEN✨<br></h3>
  <img src="https://cdn.discordapp.com/attachments/968115172843589702/970055839597621318/nitro.ico">
</div>

<div align="center">
  <h3></h3>
  <h4>Nitro Generator And Checker And Send You Working Nitro To Your Webhook If He Find One</h4>

  <img src="https://cdn.discordapp.com/attachments/969520965438550046/969918314535088148/unknown.png">
  <h3>Dont Forget to leave a :star: Star :star:<h3>
  <hr style="border-radius: 2%; margin-top: 60px; margin-bottom: 60px;" noshade="" size="20" width="100%">
</div>

#### Features
- 🟩 Proxy Support
- 🟩 Fast Generator And Checker
- 🟩 Easy to use
- 🟩 Auto Claimer
##### 🟩 = Done/Working | 🟨 = In development | ⬛️ = Todo | 🟥 = Not Working

<hr style="border-radius: 2%; margin-top: 60px; margin-bottom: 60px;" noshade="" size="20" width="100%">

#### Prerequisites
- Python (ADD TO PATH)
- Git
<hr style="border-radius: 2%; margin-top: 60px; margin-bottom: 60px;" noshade="" size="20" width="100%">

#### Setup
1. Open your cli of choice
2. Clone the repository with `git clone https://github.com/TWIST-X7/Nitro-Generator`
3. Enter the dirctory with `cd Nitro-Generator`
4. Type `start launcher.bat`
5. Follow the instructions
6. Enjoy
<hr style="border-radius: 2%; margin-top: 60px; margin-bottom: 60px;" noshade="" size="20" width="100%">

#### Credits
- [addidix.#0506](https://github.com/addi00000) (For Making the README)

#### Errors?
- Make an [issue](https://github.com/TWIST-X7/Aio-Bypasser/issues)
- Join the [Discord](https://discord.gg/dGCCkkBC7d)
